/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Hilmi
 */
public class Curriculum {
    private String idCurriculum;
    private Matkul matkul;
    private Jurusan jurusan;

    public Curriculum() {
    }
    
    public Curriculum(Matkul matkul, Jurusan jurusan) {
        this.idCurriculum = jurusan.getIdJurusan()+"-"+matkul.getIdMatkul();
        this.matkul = matkul;
        this.jurusan = jurusan;
    }

    public String getIdCurriculum() {
        return idCurriculum;
    }

    public void setIdCurriculum(String idCurriculum) {
        this.idCurriculum = idCurriculum;
    }

    public Matkul getMatkul() {
        return matkul;
    }

    public void setMatkul(Matkul matkul) {
        this.matkul = matkul;
    }

    public Jurusan getJurusan() {
        return jurusan;
    }

    public void setJurusan(Jurusan jurusan) {
        this.jurusan = jurusan;
    }
    
    
}
