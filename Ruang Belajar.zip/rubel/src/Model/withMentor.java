/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author ACER
 */
public class withMentor extends Kelas {
    private String idPengajar;
    private String Materi;
    private String Soal;
    
     public withMentor() {
    }

    public withMentor(String namaKelas, String idKelas, String jam, String tanggal, int maxAnggota, int jumAnggota, Pelajar pembuat, Curriculum curriculum, String lokasi, String deskripsiKelas) {
        super(namaKelas, idKelas, jam, tanggal, maxAnggota, jumAnggota, pembuat, curriculum, lokasi, deskripsiKelas);
    }
    
    @Override
    public void buatKelas() {
        Database db = new Database();
        db.buatKelas(this);
    }

    @Override
    public void hapusKelas() {
        Database db = new Database();
        db.hapusKelas(this);
    }

    @Override
    public void joinKelas() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void outKelas() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getIdPengajar() {
        return idPengajar;
    }

    public void setIdPengajar(String idPengajar) {
        this.idPengajar = idPengajar;
    }

    

    public String getMateri() {
        return Materi;
    }

    public void setMateri(String Materi) {
        this.Materi = Materi;
    }

    public String getSoal() {
        return Soal;
    }

    public void setSoal(String Soal) {
        this.Soal = Soal;
    }
    
}

    
    
    
