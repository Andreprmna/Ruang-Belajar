/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
    import Model.*;
    import View.viewUser_DetailKelasJoin;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
    import java.sql.ResultSet;
    import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hilmi
 */
public class HandlerUser_DetailKelasJoin implements ActionListener{
    private viewUser_DetailKelasJoin Joindetail;
    
    public HandlerUser_DetailKelasJoin(){
        Joindetail = new viewUser_DetailKelasJoin();
        Joindetail.setVisible(true);
        Joindetail.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(Joindetail.getJoinKelas1())){
            Database db = new Database();
            cek c =  new cek();
            Pelajar p = c.cariPelajar_nim(Joindetail.getTampNim().getText());
            withoutMentor w = c.cariKelas_idKelasNomentor(Joindetail.getTampIdKelas1().getText());
            if (p.getJumJoin()<5) {
                joinKelas jk = new joinKelas(w,p);
                db.JoinKelas(jk);
                db.editPelajar_jumJoin(p, p.getJumJoin()+1);
                db.editKelas_jumAnggota(w,w.getJumAnggota()+1);
                javax.swing.JOptionPane.showMessageDialog(null, "Join Kelas Berhasil");
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Maaf Kamu Sudah Melebihi Kuota Join Kelas [5/5]");
            }  
            Joindetail.dispose();
        }
        
    }
    
    public void showUser_DetailKelasJoinWindow1(withoutMentor w, String NIM){
        Database db = new Database();
        cek c = new cek();
        Joindetail.getTampNim().setText(NIM);
        Joindetail.getTampIdKelas1().setText(w.getIdKelas());
        Joindetail.getTampNamaKelas1().setText(w.getNamaKelas());
        Joindetail.getTampTanggal1().setText(w.getTanggal());
        Joindetail.getTampJam1().setText(w.getJam());
        Joindetail.getTampLokasi1().setText(w.getLokasi());
        Joindetail.getTampKapasitas1().setText(w.getJumAnggota()+"/"+w.getMaxAnggota());
        Joindetail.getTampMatkul1().setText(w.getCurriculum().getMatkul().getIdMatkul()+"  "+w.getCurriculum().getMatkul().getNamaMatkul());
        Joindetail.getDeskripsiKelas1().setText(w.getDeskripsiKelas());
        int i = 0;
        ResultSet rs = null;
        try{
            rs = db.getData("select * from table_pelajar join joinKelas using (nim) where idKelas = '"+w.getIdKelas()+"';");
            DefaultTableModel model = (DefaultTableModel) Joindetail.getTableAnggota1().getModel();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                Joindetail.getTableAnggota1().setValueAt(rs.getString("nim"), i, 0);
                Joindetail.getTableAnggota1().setValueAt(rs.getString("nama"), i, 1);
                Jurusan k = c.cariJurusan_idJurusan(rs.getString("idjurusan"));
                Joindetail.getTableAnggota1().setValueAt(k.getNamaJurusan()+" "+rs.getInt("angkatan"), i, 2);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void showUser_DetailKelasJoinWindow2(withMentor w, String NIM){
        Database db = new Database();
        cek c = new cek();
        Joindetail.getTampNim().setText(NIM);
        Joindetail.getTampIdKelas1().setText(w.getIdKelas());
        Joindetail.getTampNamaKelas1().setText(w.getNamaKelas());
        Joindetail.getTampTanggal1().setText(w.getTanggal());
        Joindetail.getTampJam1().setText(w.getJam());
        Joindetail.getTampLokasi1().setText(w.getLokasi());
        Joindetail.getTampKapasitas1().setText(w.getJumAnggota()+"/"+w.getMaxAnggota());
        Joindetail.getTampMatkul1().setText(w.getCurriculum().getMatkul().getIdMatkul()+"  "+w.getCurriculum().getMatkul().getNamaMatkul());
        Joindetail.getDeskripsiKelas1().setText(w.getDeskripsiKelas());
        Pengajar o = c.cariPengjar_idPengajar(w.getIdPengajar());
        System.out.println(w.getIdPengajar());
        Pelajar q = c.cariPelajar_idPengajar(o.getIdPengajar());
        Joindetail.getTampMentor1().setText(q.getNama());
        int i = 0;
        ResultSet rs = null;
        try{
            rs = db.getData("select * from table_pelajar join joinKelas using (nim) where idKelas = '"+w.getIdKelas()+"';");
            DefaultTableModel model = (DefaultTableModel) Joindetail.getTableAnggota1().getModel();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                Joindetail.getTableAnggota1().setValueAt(rs.getString("nim"), i, 0);
                Joindetail.getTableAnggota1().setValueAt(rs.getString("nama"), i, 1);
                Jurusan k = c.cariJurusan_idJurusan(rs.getString("idjurusan"));
                Joindetail.getTableAnggota1().setValueAt(k.getNamaJurusan()+" "+rs.getInt("angkatan"), i, 2);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
}
