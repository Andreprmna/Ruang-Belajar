/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
    import Model.*;
    import View.viewUser_TampilPesan;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
/**
 *
 * @author Hilmi
 */
public class HandlerUser_TampilPesan implements ActionListener{
    private viewUser_TampilPesan tampilPesan;
    
    public HandlerUser_TampilPesan(){
        tampilPesan = new viewUser_TampilPesan();
        tampilPesan.setVisible(true);
        tampilPesan.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        Object source = e.getSource();
        if(source.equals(tampilPesan.getKembalidiPesan())){
            tampilPesan.dispose();
        }
    }
    
    public void setPesanWindow(Pesan h){
        cek x = new cek();
        tampilPesan.getTextPesan().setText(h.getIsiPesan());
        tampilPesan.getTampNimPengirim().setText(h.getNimPengirim());
        tampilPesan.getTampNamaPengirim().setText(x.cariPelajar_nim(h.getNimPengirim()).getNama());
    }
    
}
