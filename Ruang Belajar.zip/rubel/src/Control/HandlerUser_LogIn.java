/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

    import Model.*;
    import View.viewUser_LogIn;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
/**
 *
 * @author Hilmi
 */
public class HandlerUser_LogIn implements ActionListener{
     private viewUser_LogIn userLogin;
     public HandlerUser_LogIn(){
        setLookandFeel();
        userLogin = new viewUser_LogIn();
        userLogin.setVisible(true);
        userLogin.addActionListener(this);
    }
     
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(userLogin.getGotoAdminpage())){
            HandlerAdmin_LogIn f = new HandlerAdmin_LogIn();
            userLogin.dispose();
        }else if(source.equals(userLogin.getLogInUser())){
            String password = userLogin.getPassword().getText();
            String username = userLogin.getUsername().getText();
            String status = (String) userLogin.getPilihAkun().getSelectedItem();
            cek x = new cek();
            if(status=="Pelajar"){
                if(x.cekAkunPelajar(username, password)==true){
                    HandlerUser_Pelajar f = new HandlerUser_Pelajar();
                    cek c = new cek();
                    f.setPelajarWindow(c.cariPelajar_username(username));
                    userLogin.dispose();
                } else{
                    javax.swing.JOptionPane.showMessageDialog(null, "Username atau Password Salah");
                }
            } else if (status=="Pengajar") {
                Pelajar h = x.cariPelajar_username(username);

                if(x.cekAkunPelajar(username, password)==true && x.cekNimPengajar(h.getNim())==true){
                    javax.swing.JOptionPane.showMessageDialog(null, "Pengajar Loged In");
                    HandlerUser_Pengajar f = new HandlerUser_Pengajar();
                    cek c = new cek();
                    Pelajar s = x.cariPelajar_username(username);
                    String z = x.cariPengajar_nim(s.getNim());
                    Pengajar p = x.cariPengjar_idPengajar(z);
                    f.setPengajarWindow(p);
                    userLogin.dispose();

                } else if (x.cekAkunPelajar(username, password)==true && x.cekNimPengajar(h.getNim())==false){
                    javax.swing.JOptionPane.showMessageDialog(null, "Maaf, Anda Bukan Pengajar");
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Username atau Password Salah");
                }
            }
            userLogin.getPassword().setText("");
            userLogin.getUsername().setText("");
        }
    }
    
    public void setLookandFeel(){
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(viewUser_LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(viewUser_LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(viewUser_LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(viewUser_LogIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {
        new HandlerUser_LogIn();
    }
}
