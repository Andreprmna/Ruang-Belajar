/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Hilmi
 */
public class Jurusan {
    String idJurusan;
    String namaJurusan;

    public Jurusan() {
    }
    
    public Jurusan(String idJurusan, String namaJurusan) {
        this.idJurusan = idJurusan;
        this.namaJurusan = namaJurusan;
    }
    
    public String getIdJurusan() {
        return idJurusan;
    }

    public void setIdJurusan(String idJurusan) {
        this.idJurusan = idJurusan;
    }

    public String getNamaJurusan() {
        return namaJurusan;
    }

    public void setNamaJurusan(String namaJurusan) {
        this.namaJurusan = namaJurusan;
    }
    
    
}
