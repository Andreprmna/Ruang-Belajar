/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Hilmi
 */
public class joinKelas {
    private String idjoinKelas;
    private Kelas kelas;
    private Pelajar pelajar;
    
    public joinKelas(){}
    
    public joinKelas(Kelas kelas, Pelajar pelajar) {
        this.idjoinKelas = kelas.getIdKelas()+"-"+pelajar.getNim();
        this.kelas = kelas;
        this.pelajar = pelajar;
    }

    public String getIdjoinKelas() {
        return idjoinKelas;
    }

    public void setIdjoinKelas(String idjoinKelas) {
        this.idjoinKelas = idjoinKelas;
    }

    public Kelas getKelas() {
        return kelas;
    }

    public void setKelas(Kelas kelas) {
        this.kelas = kelas;
    }

    public Pelajar getPelajar() {
        return pelajar;
    }

    public void setPelajar(Pelajar pelajar) {
        this.pelajar = pelajar;
    }
    
}
