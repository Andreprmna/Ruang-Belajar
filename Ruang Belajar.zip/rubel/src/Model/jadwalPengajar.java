/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author ACER
 */
public class jadwalPengajar {
    private String idJadwal;
    private String jadwal;
    private String idPengajar;
    
    public jadwalPengajar() {};

    public jadwalPengajar(String idJadwal, String jadwal, String idPengajar) {
        this.idJadwal = idJadwal;
        this.jadwal = jadwal;
        this.idPengajar = idPengajar;
    }

    public String getIdJadwal() {
        return idJadwal;
    }

    public void setIdJadwal(String idJadwal) {
        this.idJadwal = idJadwal;
    }

    public String getJadwal() {
        return jadwal;
    }

    public void setJadwal(String jadwal) {
        this.jadwal = jadwal;
    }

    public String getIdPengajar() {
        return idPengajar;
    }

    public void setIdPengajar(String idPengajar) {
        this.idPengajar = idPengajar;
    }

    

  
    
   
    
    
    
    
    
}
