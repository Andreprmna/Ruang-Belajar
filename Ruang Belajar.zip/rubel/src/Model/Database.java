/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author Hilmi
 */
public class Database {
    private String dbuser = "root";
    private String dbpasswd = "";
    private Statement stmt = null;
    private Connection con = null;
    private ResultSet rs = null;
    public Database(){
    //Loads JDBC driver
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"JDBC Driver Error",JOptionPane.WARNING_MESSAGE);
        }
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/rubel",dbuser, dbpasswd);
            stmt = con.createStatement();
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Connection Error",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public ResultSet getData(String SQLString){
        try {
            rs = stmt.executeQuery(SQLString);
        }catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Error :"+e.getMessage(),"Communication Error",JOptionPane.WARNING_MESSAGE);
        }
        return rs;
    }
        
    public void query(String SQLString) {
        try {
            stmt.executeUpdate(SQLString);
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null,"error:"+e.getMessage(),"Communication Error",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    //Pelajar
    public void tambahPelajar(Pelajar p){
        Database db = new Database();
        String s ="insert into table_pelajar (nim, nama, idjurusan, angkatan, username, password, jumJoin) values "
                + "('"+p.getNim()+"','"+p.getNama()+"','"+p.getIdjurusan()+"',"+p.getAngkatan()+",'"+p.getUsername()+"','"+p.getPassword()+"','"+p.getJumJoin()+"');";
        db.query(s);
    }
    
    public void hapusPelajar(Pelajar p){
        Database db = new Database();
        String s ="delete from table_pelajar where nim='"+p.getNim()+"';";
        db.query(s);
    }
    
    public void editPelajar(Pelajar p, String x){
        Database db = new Database();
        String s ="update table_pelajar set nama='"+x+"' where nim='"+p.getNim()+"';";
        db.query(s);
    }
    
    public void editPelajar_jumJoin(Pelajar p, int x){
        Database db = new Database();
        String s ="update table_pelajar set jumJoin='"+x+"' where nim='"+p.getNim()+"';";
        db.query(s);
    }
    
    //Pengajar
    public void tambahPengajar(Pengajar p){
        Database db = new Database();
        String s ="insert into table_pengajar (idPengajar, nim, jumlahKeahlian) values "
                + "('"+p.getIdPengajar()+"','"+p.getNim()+"',"+p.getJumlahKeahlian()+");";
        db.query(s);
    }
    
    public void hapusPengajar(Pengajar p){
        Database db = new Database();
        String s ="delete from table_pengajar where idPengajar='"+p.getIdPengajar()+"';";
        db.query(s);
    }
    
    public void editPengajar(Pengajar p,int x){
        Database db = new Database();
        String s ="update table_pengajar set jumlahKeahlian="+x+" where idPengajar='"+p.getIdPengajar()+"';";
        db.query(s);
    }
    
    
    //Mengajar
    public void tambahMengajar(Mengajar m){
        Database db = new Database();
        String s = "insert into mengajar(idmengajar, idPengajar, idmatkul) values ('"
                +m.getIdMengajar()+"','"+m.getPengajar().getIdPengajar()+"','"+m.getMatkul().getIdMatkul()+"');";
        db.query(s);
    }
    
    public void hapusMengajar(Mengajar m){
        Database db = new Database();
        String s ="delete from mengajar where idmengajar='"+m.getIdMengajar()+"';";
        db.query(s);
    }
    
    public void hapusMengajardanPengajar(String x){
        cek c = new cek();
        try{
            Database db = new Database();
            ResultSet rs = db.getData("SELECT * FROM mengajar where idMatkul='"+x+"';");
            while(rs.next()){
                Mengajar m = c.cariMengajar_idMengajar(rs.getString("idMengajar"));
                db.hapusMengajar(m);
                Pengajar p = c.cariPengjar_idPengajar(rs.getString("idPengajar"));
                p.setJumlahKeahlian(p.getJumlahKeahlian()-1);
                if (p.getJumlahKeahlian()==0) {
                    db.hapusPengajar(p);
                } else {
                    db.editPengajar(p,p.getJumlahKeahlian());
                }
            }
            rs.close();
        }catch (Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    //Matkul
    public void tambahMatkul(Matkul m){
        Database db = new Database();
        String s = "insert into table_matakuliah(idMatkul, namaMatkul) values ('"
                +m.getIdMatkul()+"','"+m.getNamaMatkul()+"');";
        db.query(s);
    }
    
    public void hapusMatkul(Matkul m){
        Database db = new Database();
        String s ="delete from table_matakuliah where idMatkul='"+m.getIdMatkul()+"';";
        db.query(s);
    }
    
    public void editMatkul(Matkul m,String x){
        Database db = new Database();
        String s ="update table_matakuliah set namaMatkul='"+x+"' where idMatkul='"+m.getIdMatkul()+"';";
        db.query(s);
    }
    
    //Jurusan
    public void tambahJurusan(Jurusan j){
        Database db = new Database();
        String s = "insert into table_jurusan(idJurusan, namaJurusan) values ('"
                +j.getIdJurusan()+"','"+j.getNamaJurusan()+"');";
        db.query(s);
    }
    
    public void hapusJurusan(Jurusan j){
        Database db = new Database();
        String s ="delete from table_jurusan where idJurusan='"+j.getIdJurusan()+"';";
        db.query(s);
    }
    
    public void editJurusan(Jurusan j,String x){
        Database db = new Database();
        String s ="update table_jurusan set namaJurusan='"+x+"' where idJurusan='"+j.getIdJurusan()+"';";
        db.query(s);
    }
    
    //Curriculum
    public void tambahCurriculum(Curriculum c){
        Database db = new Database();
        String s = "insert into curriculum(idcurriculum, idmatkul, idjurusan) values ('"
                +c.getIdCurriculum()+"','"+c.getMatkul().getIdMatkul()+"','"+c.getJurusan().getIdJurusan()+"');";
        db.query(s);
    }
    
    public void hapusCurriculum(Jurusan j, Matkul m){
        Database db = new Database();
        String s ="delete from curriculum where idcurriculum='"+j.getIdJurusan()+"-"+m.getIdMatkul()+"';";
        db.query(s);
    }
    
    //Kelas withoutMentor   
    public void buatKelas(withoutMentor w) {
        Database db = new Database();
        String s ="insert into kelas_nomentor (idKelas, namaKelas, tanggal, jam, maxAnggota, jumAnggota, nim, idcurriculum, lokasi, deskripsiKelas) values "
                + "('"+w.getIdKelas()+"','"+w.getNamaKelas()+"','"+w.getTanggal()+"','"+w.getJam()+"','"+w.getMaxAnggota()+"','"+w.getJumAnggota()+"','"+w.getPembuat().getNim()+"','"+w.getCurriculum().getIdCurriculum()+"','"+w.getLokasi()+"','"+w.getDeskripsiKelas()+"');";
        db.query(s);
    }
    //Kelas withmentor
    public void buatKelas(withMentor w) {
        Database db = new Database();
        String a = "Materi Belum Diinput";
        String b = "Soal Belum Diinput";
        String s ="insert into kelas_withmentor (idKelas, namaKelas, tanggal, jam, maxAnggota, jumAnggota, nim, idPengajar, idcurriculum, lokasi, deskripsiKelas, materi, soal) values "
                + "('"+w.getIdKelas()+"','"+w.getNamaKelas()+"','"+w.getTanggal()+"','"+w.getJam()+"','"+w.getMaxAnggota()+"','"+w.getJumAnggota()+"','"+w.getPembuat().getNim()+"','"+w.getIdPengajar()+"','"+w.getCurriculum().getIdCurriculum()+"','"+w.getLokasi()+"','"+w.getDeskripsiKelas()+"','"+a+"','"+b+"');";
        db.query(s);
    }
    
    
    
    
    
    public void hapusKelas(withoutMentor w) {
        Database db = new Database();
        String s ="delete from kelas_nomentor where idKelas='"+w.getIdKelas()+"';";
        db.query(s);
    }
    
    public void hapusKelas(withMentor w) {
        Database db = new Database();
        String s ="delete from kelas_nomentor where idKelas='"+w.getIdKelas()+"';";
        db.query(s);
    }
    
    
    
    public void editKelas_jumAnggota(withoutMentor w, int x){
        Database db = new Database();
        String s ="update kelas_nomentor set jumAnggota='"+x+"' where idKelas='"+w.getIdKelas()+"';";
        db.query(s);
    }
    
    //join Kelas
    public void JoinKelas(joinKelas j){
        Database db = new Database();
        String s ="insert into joinKelas (idjoinKelas, idKelas, nim) values "
                + "('"+j.getIdjoinKelas()+"','"+j.getKelas().getIdKelas()+"','"+j.getPelajar().getNim()+"');";
        db.query(s);
    }
    
    public void deJoinKelas(joinKelas j){
        Database db = new Database();
        String s ="delete from joinKelas where idjoinKelas='"+j.getIdjoinKelas()+"';";
        db.query(s);
    }
    
    public void addJadwalPengajar (jadwalPengajar m) {
        Database db = new Database();
        String s = "insert into jadwal_pengajar (idJadwal, jadwal, idPengajar) values "
                + "('"+m.getIdJadwal()+"','"+m.getJadwal()+"','"+m.getIdPengajar()+"');";
        db.query(s);
    }
    
    public void HapusJadwalPengajar (String x) {
        Database db = new Database();
        String s ="delete from jadwal_pengajar where idJadwal='"+x+"';";
        db.query(s);
        
    }
    
    public void editKelasMateri(withMentor p, String x, String y){
        Database db = new Database();
        String s ="update kelas_withmentor set materi='"+x+"'  where idKelas='"+p.getIdKelas()+"';";
        String z ="update kelas_withmentor set soal='"+y+"' where idKelas='"+p.getIdKelas()+"';";
        db.query(s);
        db.query(z);
    }
    
    //Pesan
    public void tambahPesan(Pesan p) {
        Database db = new Database();
        cek x = new cek();
        int y = x.cekidxPesan();
        p.setIdPesan(y+1);
        String s ="insert into pesan(idPesan,NimPengirim, NimPenerima, isiPesan) values "
                + "('"+p.getIdPesan()+"','"+p.getNimPengirim()+"','"+p.getNimPenerima()+"','"+p.getIsiPesan()+"');";
        db.query(s);
    }
    
    
}
