/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

    import Model.*;
    import View.viewUser_Pelajar;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
    import java.sql.ResultSet;
    import java.text.SimpleDateFormat;
    import java.util.Date;
import javax.swing.JOptionPane;
    import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Hilmi
 */
public class HandlerUser_Pelajar implements ActionListener{
    private viewUser_Pelajar pelajar;
    
    public HandlerUser_Pelajar(){
        pelajar = new viewUser_Pelajar();
        pelajar.setVisible(true);
        pelajar.addActionListener(this);
        
    }
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(pelajar.getComboTahunTbhRubel())){
            showComboTanggalTbhRubel();
            showComboBulanTbhRubel();
        } else if(source.equals(pelajar.getComboBulanTbhRubel())){
            showComboTanggalTbhRubel();
        } else if(source.equals(pelajar.getBuatKelas())){
            if (pelajar.getNamakelasTbhRubel().getText().isEmpty()==false&&pelajar.getLokasiTbhRubel().getText().isEmpty()==false&&pelajar.getDeskripsiKelasTbhRubel().getText().isEmpty()==false) {
                Database db = new Database();
                cek x = new cek();
                Pelajar p = x.cariPelajar_nim(pelajar.getTampNIM().getText());
                Jurusan j = x.cariJurusan_idJurusan(p.getIdjurusan());
                String s = x.splitText((String) pelajar.getComboMatkulTbhRubel().getSelectedItem());
                Matkul m = x.cariMatkul_idMatkul(s);
                Curriculum c = x.cariCurriculum_idCurriculum(j.getIdJurusan()+"-"+m.getIdMatkul());
                withoutMentor k = new withoutMentor();
                String tampId = p.getNim()+"-"+x.randomNumberGenerator();
                while (x.cekidKelasNomentor(tampId)==true){
                    tampId = p.getNim()+"-"+x.randomNumberGenerator();
                }
                k.setIdKelas(tampId);
                k.setNamaKelas(pelajar.getNamakelasTbhRubel().getText());
                String Tanggal = pelajar.getComboTahunTbhRubel().getSelectedItem()+"-"+x.cekNomorBulan((String)pelajar.getComboBulanTbhRubel().getSelectedItem())+"-"+pelajar.getComboTanggalTbhRubel().getSelectedItem();
                k.setTanggal(Tanggal);
                String jam = pelajar.getJamTbhRubel().getValue()+":"+pelajar.getMenitTbhRubel().getValue();
                k.setJam(jam);
                k.setMaxAnggota(Integer.parseInt((String) pelajar.getMaxAnggotaTbhRubel().getSelectedItem()));
                k.setJumAnggota(1);
                k.setPembuat(p);
                k.setCurriculum(c);
                k.setLokasi(pelajar.getLokasiTbhRubel().getText());
                k.setDeskripsiKelas(pelajar.getDeskripsiKelasTbhRubel().getText());
                if(p.getJumJoin()<5){
                    joinKelas jk = new joinKelas(k,p);
                    k.buatKelas();
                    db.JoinKelas(jk);
                    db.editPelajar_jumJoin(p, p.getJumJoin()+1);
                    javax.swing.JOptionPane.showMessageDialog(null, "Buat Kelas Berhasil");
                } else{
                    javax.swing.JOptionPane.showMessageDialog(null, "Maaf Kamu Sudah Melebihi Kuota Join Kelas [5/5]");
                }
                pelajar.getNamakelasTbhRubel().setText("");
                pelajar.getDeskripsiKelasTbhRubel().setText("");
                pelajar.getLokasiTbhRubel().setText("");
                showTableKelasSaya();
                showTableKelasJoin();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Isi Data yang Masih Kosong");
        
            }
        }
            else if (source.equals(pelajar.getTambahMentor())) {
                if (pelajar.getNamakelasTbhRubel().getText().isEmpty()==false&&pelajar.getLokasiTbhRubel().getText().isEmpty()==false&&pelajar.getDeskripsiKelasTbhRubel().getText().isEmpty()==false) {
                Database db = new Database();
                cek x = new cek();
                Pelajar p = x.cariPelajar_nim(pelajar.getTampNIM().getText());
                Jurusan j = x.cariJurusan_idJurusan(p.getIdjurusan());
                String s = x.splitText((String) pelajar.getComboMatkulTbhRubel().getSelectedItem());
                Matkul m = x.cariMatkul_idMatkul(s);
                Curriculum c = x.cariCurriculum_idCurriculum(j.getIdJurusan()+"-"+m.getIdMatkul());
                withMentor k = new withMentor();
                String tampId = p.getNim()+"-"+x.randomNumberGenerator();
                while (x.cekidKelasNomentor(tampId)==true){
                    tampId = p.getNim()+"-"+x.randomNumberGenerator();
                }
                k.setIdKelas(tampId);
                k.setNamaKelas(pelajar.getNamakelasTbhRubel().getText());
                String d;
                if (Integer.parseInt(pelajar.getComboTanggalTbhRubel().getSelectedItem().toString()) < 10  ) {
                     d = "0"+((String)pelajar.getComboTanggalTbhRubel().getSelectedItem());
                    
                }else {
                     d = ((String)pelajar.getComboTanggalTbhRubel().getSelectedItem());
                }
                String Tanggal = pelajar.getComboTahunTbhRubel().getSelectedItem()+"-"+x.cekNomorBulan((String)pelajar.getComboBulanTbhRubel().getSelectedItem())+"-"+d;
                k.setTanggal(Tanggal);
                String jam = pelajar.getJamTbhRubel().getValue()+":"+pelajar.getMenitTbhRubel().getValue();
                k.setJam(jam);
                k.setMaxAnggota(Integer.parseInt((String) pelajar.getMaxAnggotaTbhRubel().getSelectedItem()));
                k.setJumAnggota(1);
                k.setPembuat(p);
                k.setCurriculum(c);
                k.setLokasi(pelajar.getLokasiTbhRubel().getText());
                k.setDeskripsiKelas(pelajar.getDeskripsiKelasTbhRubel().getText());
                
                withoutMentor w = x.cariKelas_idKelasNomentor(pelajar.getIdKelasJouinRubel().getText());
                HandlerPengajarList h = new HandlerPengajarList();
                h.setPengajarListWindow(m,k);
                
                
                
                
                
                }
        }
   
       
        else if(source.equals(pelajar.getCariHpsRubel())){
            if (pelajar.getIdRubelHpsRubel().getText().isEmpty()==false) {
                String a = pelajar.getIdRubelHpsRubel().getText();
                cek x =new cek();
                withoutMentor h = x.cariKelas_idKelasNomentor(a);
                if (h!=null) {
                    System.out.println(h.getPembuat().getNim());
                    if (h.getPembuat().getNim().equals(pelajar.getTampNIM().getText())) {
                        pelajar.getTampHpsIdRubel().setText(a);
                        pelajar.getNamakelasHpsRubel().setText(h.getNamaKelas());
                        pelajar.getLokasiHpsRubel().setText(h.getLokasi());
                        pelajar.getTampHpstglRubel().setText(h.getTanggal());
                        pelajar.getTampHpsJam().setText(h.getJam());
                        pelajar.getTampHpsMaxAnggota().setText(Integer.toString(h.getMaxAnggota()));
                        Matkul m = x.cariMatkul_idMatkul(h.getCurriculum().getMatkul().getIdMatkul());
                        pelajar.getMatkulHpsRubel().setText(m.getIdMatkul()+"  "+m.getNamaMatkul());
                        pelajar.getDeskripsiKelasHpsRubel().setText(h.getDeskripsiKelas());
                    } else{
                        javax.swing.JOptionPane.showMessageDialog(null, "Bukan Kelas Yang Anda Buat test");
                    }
                    
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "NIM Tidak Ditemukan");
                }
                pelajar.getIdRubelHpsRubel().setText("");
            }
        } else if(source.equals(pelajar.getHapusRubel())){
            if (!"...".equals(pelajar.getTampHpsIdRubel().getText())) {
                Database db = new Database();
                cek x = new cek();
                withoutMentor h = x.cariKelas_idKelasNomentor(pelajar.getTampHpsIdRubel().getText());
                Pelajar p = h.getPembuat();
                db.editPelajar_jumJoin(p, p.getJumJoin()-1);
                h.hapusKelas();
                javax.swing.JOptionPane.showMessageDialog(null, "Hapus Kelas Berhasil");
                pelajar.getTampHpsIdRubel().setText("...");
                pelajar.getNamakelasHpsRubel().setText("");
                pelajar.getLokasiHpsRubel().setText("");
                pelajar.getTampHpstglRubel().setText("...");
                pelajar.getTampHpsJam().setText("...");
                pelajar.getTampHpsMaxAnggota().setText("...");
                pelajar.getMatkulHpsRubel().setText("");
                pelajar.getDeskripsiKelasHpsRubel().setText("");
                showTableKelasSaya();
                showTableKelasJoin();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        }else if(source.equals(pelajar.getCekUsername())){
            if (pelajar.getUsernameCariPelajar().getText().isEmpty()==false) {
                String a = pelajar.getUsernameCariPelajar().getText();
                cek x =new cek();
                Pelajar h = x.cariPelajar_username(a);
                if (h!=null) {
                    Jurusan k = x.cariJurusan_idJurusan(h.getIdjurusan());
                    if (x.cekNimPengajar(a)==true) {
                        javax.swing.JOptionPane.showMessageDialog(null, h.getNama()+" Juga Akan Terhapus Dari Daftar Pengajar");
                    }
                    pelajar.getNimCekUsername().setText(h.getNim());
                    pelajar.getNamaCekUsername().setText(h.getNama());
                    pelajar.getCekJurusanUsername().setText(k.getNamaJurusan() +" "+h.getAngkatan());
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Username Tidak Ditemukan");
                }
                pelajar.getUsernameCariPelajar().setText("");
            } 
        }else if(source.equals(pelajar.getAddToTujuan())){
            if (pelajar.getNimCekUsername().getText().isEmpty()==false) {
                pelajar.getNamaPenerima().setText(pelajar.getNamaCekUsername().getText());
                pelajar.getNimPenerima().setText(pelajar.getNimCekUsername().getText());
                pelajar.getCekJurusanUsername().setText("");
                pelajar.getNamaCekUsername().setText("");
                pelajar.getNimCekUsername().setText("");
            } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Mahasiswa Terlebih Dahulu");
            }
        }else if(source.equals(pelajar.getClearPesan())){
            pelajar.getNamaPenerima().setText("");
            pelajar.getNimPenerima().setText("...");
            pelajar.getTextPesan().setText("");
        }else if(source.equals(pelajar.getKirimPesan())){
            if (!"...".equals(pelajar.getNimPenerima().getText())) {
                Database db = new Database();
                Pesan p = new Pesan();
                cek x = new cek();
                p.setNimPengirim(pelajar.getTampNIM().getText());
                p.setNimPenerima(pelajar.getNimPenerima().getText());
                p.setIsiPesan(pelajar.getTextPesan().getText());
                if ( x.cekNimPelajar(p.getNimPenerima()) == true ) {
                    db.tambahPesan(p);
                    javax.swing.JOptionPane.showMessageDialog(null, "Pesan Terkirim");
                    showTablePesanTerkirim();
                    showTablePesanDiterima();
                    pelajar.getNamaPenerima().setText("");
                    pelajar.getTextPesan().setText("");
                }else{
                    javax.swing.JOptionPane.showMessageDialog(null, "Cek Kembali Nim Yang Dimasukkan");
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Mahasiswa Terlebih Dahulu");
            }
        }else if(source.equals(pelajar.getLihatPesan())){
            if (!"".equals(pelajar.getTampidPesan().getText())) {
                Database db = new Database();
                boolean cek =false;
                int c = Integer.parseInt(pelajar.getTampidPesan().getText());
                ResultSet rs = null;
                rs = db.getData("select * from pesan where NimPengirim='"+pelajar.getTampNIM().getText()+"' OR NimPenerima='"+pelajar.getTampNIM().getText()+"';");
                try{
                    while(rs.next()){
                        if(c == rs.getInt("idPesan")){
                            cek = true;
                        }
                    }
                    rs.close();
                }catch (Exception E){
                    JOptionPane.showMessageDialog(null,""+E.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
                }
                if (cek == true) {
                    HandlerUser_TampilPesan f = new HandlerUser_TampilPesan();
                    cek x = new cek();
                    int idx = Integer.parseInt(pelajar.getTampidPesan().getText());
                    f.setPesanWindow(x.cariPesan_idPesan(idx));
                }else {
                    javax.swing.JOptionPane.showMessageDialog(null, "IdPesan tidak ada di daftar pesan Anda");
                }
            }
        } else if(source.equals(pelajar.getComboTahunCariRubel())){
            showComboTanggalCariRubel();
            showComboBulanCariRubel();
            showTableCariKelas();
        } else if(source.equals(pelajar.getComboBulanCariRubel())){
            showComboTanggalCariRubel();
            showTableCariKelas();
        } else if (source.equals(pelajar.getComboTanggalCariRubel())) {
            showTableCariKelas();
        } else if (source.equals(pelajar.getSeeDetailRubel())) {
            if (pelajar.getIdKelasJouinRubel().getText().isEmpty()==false) {
                cek x = new cek();
                if (pelajar.getWithMentorCheckJoin().isSelected()==false) {
                    withoutMentor w = x.cariKelas_idKelasNomentor(pelajar.getIdKelasJouinRubel().getText());
                    HandlerUser_DetailKelasJoin h = new HandlerUser_DetailKelasJoin();
                    h.showUser_DetailKelasJoinWindow1(w, pelajar.getTampNIM().getText());
                } else {
                    withMentor v = x.cariKelas_idKelasWithmentor(pelajar.getIdKelasJouinRubel().getText());
                    HandlerUser_DetailKelasJoin h = new HandlerUser_DetailKelasJoin();
                    h.showUser_DetailKelasJoinWindow2(v, pelajar.getTampNIM().getText());
                }
                
            }
        } else if(source.equals(pelajar.getKeluar())){
            HandlerUser_LogIn f = new HandlerUser_LogIn();
            pelajar.dispose();
        } else if ((source.equals(pelajar.getRefresjKelasJoined()))) {
            showTableKelasJoin();
            showTableKelasSaya();
        }else if ((source.equals(pelajar.getRefreshCariRubel()))){
            showTableCariKelas();
        }else if ((source.equals(pelajar.getRefresh()))){
            showTablePesanTerkirim();
            showTablePesanDiterima();
        }
    }
    
    //Tampil Table, Combo dan List untuk Jframe
    public void setPelajarWindow(Pelajar h){
        pelajar.getTampName().setText(h.getNama());
        pelajar.getTampNIM().setText(h.getNim());
        showComboTahun();
        showComboBulanTbhRubel();
        showComboBulanCariRubel();
        showComboTanggalTbhRubel();
        showComboBulanCariRubel();
        showtanggal();
        showComboMaxAnggota();
        showTableKelasSaya();
        showcomboSelectedMatkul();
        showTablePesanTerkirim();
        showTablePesanDiterima();
        showTableKelasJoin();
        showTableCariKelas();
        showComboTahunCariRubel();
        
    }
    
    public void showTableKelasSaya(){
        Database db = new Database();
        int i = 0;
        ResultSet rs = null;
        try{
            rs = db.getData("select * from kelas_nomentor where nim ='"+pelajar.getTampNIM().getText()+"';");
            DefaultTableModel model = (DefaultTableModel) pelajar.getKelasSayaTable().getModel();
            cek x = new cek();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                Curriculum c = x.cariCurriculum_idCurriculum(rs.getString("idCurriculum"));
                Matkul m = c.getMatkul();
                pelajar.getKelasSayaTable().setValueAt(rs.getString("idKelas"), i, 0);
                pelajar.getKelasSayaTable().setValueAt(rs.getString("namaKelas"), i, 1);
                pelajar.getKelasSayaTable().setValueAt(rs.getString("deskripsiKelas"), i, 2);
                pelajar.getKelasSayaTable().setValueAt(m.getIdMatkul()+"  "+m.getNamaMatkul(), i, 3);
                pelajar.getKelasSayaTable().setValueAt(rs.getString("jumAnggota")+"/"+rs.getString("maxAnggota"), i, 4);
                pelajar.getKelasSayaTable().setValueAt(rs.getString("tanggal"), i, 5);
                pelajar.getKelasSayaTable().setValueAt(rs.getString("jam"), i, 6);
                pelajar.getKelasSayaTable().setValueAt(rs.getString("Lokasi"), i, 7);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void showTableKelasJoin(){
        Database db = new Database();
        int i = 0;
        ResultSet rs = null;
        try{
            rs = db.getData("select * from kelas_nomentor join joinkelas using (idKelas) where joinkelas.nim ='"+pelajar.getTampNIM().getText()+"';");
            DefaultTableModel model = (DefaultTableModel) pelajar.getKelasSayaTableJoin().getModel();
            cek x = new cek();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                Curriculum c = x.cariCurriculum_idCurriculum(rs.getString("idCurriculum"));
                Matkul m = c.getMatkul();
                pelajar.getKelasSayaTableJoin().setValueAt(rs.getString("idKelas"), i, 0);
                pelajar.getKelasSayaTableJoin().setValueAt(rs.getString("namaKelas"), i, 1);
                pelajar.getKelasSayaTableJoin().setValueAt(rs.getString("deskripsiKelas"), i, 2);
                pelajar.getKelasSayaTableJoin().setValueAt(m.getIdMatkul()+"  "+m.getNamaMatkul(), i, 3);
                pelajar.getKelasSayaTableJoin().setValueAt(rs.getString("jumAnggota")+"/"+rs.getString("maxAnggota"), i, 4);
                pelajar.getKelasSayaTableJoin().setValueAt(rs.getString("tanggal"), i, 5);
                pelajar.getKelasSayaTableJoin().setValueAt(rs.getString("jam"), i, 6);
                pelajar.getKelasSayaTableJoin().setValueAt(rs.getString("Lokasi"), i, 7);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void showcomboSelectedMatkul(){
        pelajar.getComboMatkulTbhRubel().removeAllItems();
        pelajar.getComboMatkulCariRubel().removeAllItems();
        cek x = new cek();
        if (!"...".equals(pelajar.getTampNIM().getText())) {
            Pelajar p = x.cariPelajar_nim(pelajar.getTampNIM().getText());
            try{
                Database db = new Database();
                ResultSet rs = db.getData("select * from curriculum where idJurusan='"+p.getIdjurusan()+"';");
                while(rs.next()){
                    Matkul y = x.cariMatkul_idMatkul(rs.getString("idMatkul"));
                    pelajar.getComboMatkulTbhRubel().addItem(rs.getString("idMatkul")+"   "+y.getNamaMatkul());
                    pelajar.getComboMatkulCariRubel().addItem(rs.getString("idMatkul")+"   "+y.getNamaMatkul());
                }
                rs.close();
            } catch (Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        } 
    }
    
    public void showComboTanggalTbhRubel(){
        Date now =new Date();        
        pelajar.getComboTanggalTbhRubel().removeAllItems();
        cek c = new cek();
        
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy");
        if ((String) pelajar.getComboTahunTbhRubel().getSelectedItem()!=null) {
            int tahun = Integer.parseInt((String) pelajar.getComboTahunTbhRubel().getSelectedItem());
            String thn = dateFormatter.format(now);

            String bulan = ((String) pelajar.getComboBulanTbhRubel().getSelectedItem());
            int bln = now.getMonth()+1;
            String bulannow = c.cekNamaBulan(bln);


            if(bulan=="Januari" || bulan=="Maret" || bulan=="Mei" || bulan=="Juli" || bulan=="Agustus" || bulan=="Oktober" || bulan=="Desember"){
                if(tahun==Integer.parseInt(thn) && bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 31; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));
                    }
                } else {
                    for (int i = 1; i <= 31; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));

                    }
                }
            } else if(bulan=="Februari" && c.cekKabisat(tahun)==true){
                if(tahun==Integer.parseInt(thn)&& bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 29; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));
                    }
                } else{
                    for (int i = 1; i <= 29; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));
                    }
                }
            } else if(bulan=="Februari" && c.cekKabisat(tahun)==false){
                if(tahun==Integer.parseInt(thn)&& bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 28; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));
                    }
                } else{
                    for (int i = 1; i <= 28; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));
                    }
                }
            } else {
               if(tahun==Integer.parseInt(thn)&& bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 30; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));
                    }
                } else {
                    for (int i = 1; i <= 30; i++) {
                        pelajar.getComboTanggalTbhRubel().addItem(Integer.toString(i));
                    }
                }
            }
        }
    }
    
    public void showComboTanggalCariRubel(){
        Date now =new Date();        
        pelajar.getComboTanggalCariRubel().removeAllItems();
        cek c = new cek();
        
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy");
        if ((String) pelajar.getComboTahunCariRubel().getSelectedItem()!=null) {
            int tahun = Integer.parseInt((String) pelajar.getComboTahunCariRubel().getSelectedItem());
            String thn = dateFormatter.format(now);

            String bulan = ((String) pelajar.getComboBulanCariRubel().getSelectedItem());
            int bln = now.getMonth()+1;
            String bulannow = c.cekNamaBulan(bln);

            if(bulan=="Januari" || bulan=="Maret" || bulan=="Mei" || bulan=="Juli" || bulan=="Agustus" || bulan=="Oktober" || bulan=="Desember"){
                if(tahun==Integer.parseInt(thn) && bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 31; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                } else {
                    for (int i = 1; i <= 31; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                }
            } else if(bulan=="Februari" && c.cekKabisat(tahun)==true){
                if(tahun==Integer.parseInt(thn) && bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 29; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                } else {
                    for (int i = 1; i <= 29; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                }
            } else if(bulan=="Februari" && c.cekKabisat(tahun)==false){
                if(tahun==Integer.parseInt(thn) && bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 28; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                } else {
                    for (int i = 1; i <= 28; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                }
            } else {
               if(tahun==Integer.parseInt(thn) && bulannow==bulan){
                    for (int i = now.getDate()+1; i <= 30; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                } else {
                    for (int i = 1; i <= 30; i++) {
                        pelajar.getComboTanggalCariRubel().addItem(Integer.toString(i));
                    }
                }
            }
        }
    }
    
    public void namaBulan(int x){
        cek c = new cek();
        for (int i = x; i <= 12; i++) {
            pelajar.getComboBulanTbhRubel().addItem(c.cekNamaBulan(i));
        }
    }
    
    public void namaBulanCariRubel(int x){
        cek c = new cek();
        for (int i = x; i <= 12; i++) {
            pelajar.getComboBulanCariRubel().addItem(c.cekNamaBulan(i));
        }
    }
    
    public void showComboBulanTbhRubel(){
        pelajar.getComboBulanTbhRubel().removeAllItems();
        Date now =new Date();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy");
        if ((String) pelajar.getComboTahunTbhRubel().getSelectedItem()!=null) {
            int tahun = Integer.parseInt((String) pelajar.getComboTahunTbhRubel().getSelectedItem());
            String thn = dateFormatter.format(now);
            if (tahun==Integer.parseInt(thn)) {
                namaBulan(now.getMonth()+1);
            } else{
                namaBulan(1);
            }
        }
    }
    
    public void showComboBulanCariRubel(){
        pelajar.getComboBulanCariRubel().removeAllItems();
        Date now =new Date();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy");
        if ((String) pelajar.getComboTahunCariRubel().getSelectedItem()!=null) {
            int tahun = Integer.parseInt((String) pelajar.getComboTahunCariRubel().getSelectedItem());
            String thn = dateFormatter.format(now);
            if (tahun==Integer.parseInt(thn)) {
                namaBulanCariRubel(now.getMonth()+1);
            } else{
                namaBulanCariRubel(1);
            }
        }
    }
    
    public void showComboTahun(){
        pelajar.getComboTahunTbhRubel().removeAllItems();
        Date now = new Date();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy");
        int tahun =Integer.parseInt(dateFormatter.format(now));
        
        for (int i = 0; i <= 1; i++) {
            pelajar.getComboTahunTbhRubel().addItem(Integer.toString(tahun+i));
        }
    }
    
    public void showComboTahunCariRubel(){
        pelajar.getComboTahunCariRubel().removeAllItems();
        Date now = new Date();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy");
        int tahun =Integer.parseInt(dateFormatter.format(now));
        
        for (int i = 0; i <= 1; i++) {
            pelajar.getComboTahunCariRubel().addItem(Integer.toString(tahun+i));
        }
    }
    
    public void showtanggal(){
        Date now = new Date();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("EEEEEE dd / MM / yyyy");
        pelajar.getTanggal().setText(dateFormatter.format(now));
    }
    
    public void showComboMaxAnggota(){
        for (int i = 3; i <= 5; i++) {
            pelajar.getMaxAnggotaTbhRubel().addItem(Integer.toString(i));
        }
    }
    
    public void showTableCariKelas(){
        cek c = new cek();
        if (!"...".equals(pelajar.getTampNIM().getText())) {
            cek x = new cek();
            Pelajar p = x.cariPelajar_nim(pelajar.getTampNIM().getText());
            String Tanggal = pelajar.getComboTahunCariRubel().getSelectedItem()+"-"+x.cekNomorBulan((String)pelajar.getComboBulanCariRubel().getSelectedItem())+"-"+pelajar.getComboTanggalCariRubel().getSelectedItem();
            if((String) pelajar.getComboMatkulCariRubel().getSelectedItem()!=null){
                String s = x.splitText((String) pelajar.getComboMatkulCariRubel().getSelectedItem());
                Matkul m = x.cariMatkul_idMatkul(s);
                Curriculum cu = x.cariCurriculum_idCurriculum(p.getIdjurusan()+"-"+m.getIdMatkul());
                Database db = new Database();
                int i = 0;
                ResultSet rs = null;
                try{
                    if (pelajar.getWithMentorCheckCari().isSelected()==false) {
                        rs = db.getData("select * from kelas_nomentor where idcurriculum='"+cu.getIdCurriculum()+"'and tanggal='"+Tanggal+"' and jumAnggota<>maxAnggota and idKelas <> all (select idKelas from joinkelas where nim = '"+p.getNim()+"');");
                        DefaultTableModel model = (DefaultTableModel) pelajar.getCariKelasTable().getModel();
                        model.setRowCount(0);
                        while (rs.next()){
                            model.setRowCount(i+1);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("idKelas"), i, 0);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("namaKelas"), i, 1);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("deskripsiKelas"), i, 2);
                            pelajar.getCariKelasTable().setValueAt(m.getIdMatkul()+"  "+m.getNamaMatkul(), i, 3);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("jumAnggota")+"/"+rs.getString("maxAnggota"), i, 4);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("tanggal"), i, 5);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("jam"), i, 6);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("Lokasi"), i, 7);
                            i=i+1;
                        }
                        rs.close();
                    } else {
                        rs = db.getData("select * from kelas_withmentor where idcurriculum='"+cu.getIdCurriculum()+"'and tanggal='"+Tanggal+"' and jumAnggota<>maxAnggota and idKelas <> all (select idKelas from joinkelas where nim = '"+p.getNim()+"');");
                        DefaultTableModel model = (DefaultTableModel) pelajar.getCariKelasTable().getModel();
                        model.setRowCount(0);
                        while (rs.next()){
                            model.setRowCount(i+1);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("idKelas"), i, 0);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("namaKelas"), i, 1);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("deskripsiKelas"), i, 2);
                            pelajar.getCariKelasTable().setValueAt(m.getIdMatkul()+"  "+m.getNamaMatkul(), i, 3);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("jumAnggota")+"/"+rs.getString("maxAnggota"), i, 4);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("tanggal"), i, 5);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("jam"), i, 6);
                            pelajar.getCariKelasTable().setValueAt(rs.getString("Lokasi"), i, 7);
                            Pengajar o = x.cariPengjar_idPengajar(rs.getString("idPengajar"));
                            Pelajar q = x.cariPelajar_idPengajar(o.getIdPengajar());
                            pelajar.getCariKelasTable().setValueAt(q.getNama(), i, 8);
                            i=i+1;
                        }
                        rs.close();
                    }
                    
                } catch(Exception e){
                    javax.swing.JOptionPane.showMessageDialog(null, "Error");
                }
            }
            
            
        }
    }
    
    public void showTablePesanTerkirim(){
        cek c = new cek();
        if (!"...".equals(pelajar.getTampNIM().getText())) {
            Pelajar p = c.cariPelajar_nim(pelajar.getTampNIM().getText());
            Database db = new Database();
            int i = 0;
            ResultSet rs = null;
            try{

                rs = db.getData("select * from pesan where NimPengirim='"+p.getNim()+"';");
                DefaultTableModel model = (DefaultTableModel) pelajar.getTablePesanTerkirim().getModel();
                model.setRowCount(0);
                while (rs.next()){
                    model.setRowCount(i+1);
                    pelajar.getTablePesanTerkirim().setValueAt(rs.getString("idPesan"), i, 0);
                    pelajar.getTablePesanTerkirim().setValueAt(rs.getString("NimPenerima"), i, 1);
                    pelajar.getTablePesanTerkirim().setValueAt(rs.getString("IsiPesan"), i, 2);
                    i=i+1;
                }
                rs.close();
            } catch(Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
    
    public void showTablePesanDiterima(){
        cek c = new cek();
        if (!"...".equals(pelajar.getTampNIM().getText())) {
            Pelajar p = c.cariPelajar_nim(pelajar.getTampNIM().getText());
            Database db = new Database();
            int i = 0;
            ResultSet rs = null;
            try{

                rs = db.getData("select * from pesan where NimPenerima='"+p.getNim()+"';");
                DefaultTableModel model = (DefaultTableModel) pelajar.getTablePesanDiterima().getModel();
                model.setRowCount(0);
                while (rs.next()){
                    model.setRowCount(i+1);
                    pelajar.getTablePesanDiterima().setValueAt(rs.getString("idPesan"), i, 0);
                    pelajar.getTablePesanDiterima().setValueAt(rs.getString("NimPengirim"), i, 1);
                    pelajar.getTablePesanDiterima().setValueAt(rs.getString("IsiPesan"), i, 2);
                    i=i+1;
                }
                rs.close();
            } catch(Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
    
    public static void main(String[] args) {
        new HandlerUser_Pelajar();
    }
}
