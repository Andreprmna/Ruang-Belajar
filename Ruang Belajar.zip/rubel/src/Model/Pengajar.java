/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Hilmi
 */
public class Pengajar extends Pelajar{
    private String idPengajar;
    private int jumlahKeahlian;

    public Pengajar() {
    }

    public Pengajar(String nama, String nim, String idjurusan, int angkatan, String username, String password, int jumJoin) {
        super(nama, nim, idjurusan, angkatan, username, password, jumJoin);
        this.idPengajar = super.getNim();
        this.jumlahKeahlian = 0;
    }
    
    public String getIdPengajar() {
        return idPengajar;
    }

    public void setIdPengajar(String idPengajar) {
        this.idPengajar = idPengajar;
    }

    public int getJumlahKeahlian() {
        return jumlahKeahlian;
    }

    public void setJumlahKeahlian(int jumlahKeahlian) {
        this.jumlahKeahlian = jumlahKeahlian;
    }
    
    
}
