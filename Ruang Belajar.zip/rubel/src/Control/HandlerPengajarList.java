/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.*;
import View.viewPengajarList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ACER
 */
public class HandlerPengajarList implements ActionListener {
    private viewPengajarList list;
    private withMentor kelas;
    private Matkul matkul;

    public HandlerPengajarList() {
        list = new viewPengajarList();
        list.setVisible(true);
        list.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
         if(source.equals(list.getTambahPengajar())){
            cek x = new cek();
            boolean a = x.cekidPengajar(list.getListidPengajar().getText(), matkul);
             if (a == true) {
                kelas.setIdPengajar(list.getListidPengajar().getText());
                Pelajar p = kelas.getPembuat();
                if(p.getJumJoin()<5){
                    //joinKelas jk = new joinKelas(kelas,p);
                    Database db = new Database();
                    kelas.buatKelas();
                    System.out.println(x.carijadwalPengajar_idPengajar_tanggal(kelas.getIdPengajar(), kelas.getTanggal()).getIdJadwal());
                    jadwalPengajar jp = x.carijadwalPengajar_idPengajar_tanggal(kelas.getIdPengajar(), kelas.getTanggal());
                    db.HapusJadwalPengajar(jp.getIdJadwal());
                    javax.swing.JOptionPane.showMessageDialog(null, "Kelas Berhasil Dibuat");
                    //db.JoinKelas(jk);
                    db.editPelajar_jumJoin(p, p.getJumJoin()+1);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Anda Telah Melebihi Kuota Join Kelas");
                }
                
                list.dispose();
             }else{
                javax.swing.JOptionPane.showMessageDialog(null, "idPengajar Yang Anda Masukkan Salah"); 
             }
            
         }else if (source.equals(list.getBatalWithMentor())){
             list.dispose();
             
         }
            
        
        
    }
    
    
    public void showTableListPengajar(){
        cek c = new cek();
        if (!"...".equals(list.getIdMatkul().getText())) {
            //Pelajar p = c.cariPelajar_nim(pelajar.getTampNIM().getText());
            Database db = new Database();
            int i = 0;
            ResultSet rs = null;
            String a = list.getIdMatkul().getText();
            String b = list.getTanggalListPengajar().getText();
            try{
                
                rs = db.getData("select idPengajar, jadwal, nama from mengajar join jadwal_pengajar using (idPengajar) join table_pengajar using (idPengajar) join table_pelajar using (nim) where idMatkul='"+a+"';");
                DefaultTableModel model = (DefaultTableModel) list.getTableListPengajar().getModel();
                model.setRowCount(0);
                while (rs.next()){
                    model.setRowCount(i+1);
                    if ((rs.getString("jadwal").equals(b))) {
                        System.out.println("TEST");
                        list.getTableListPengajar().setValueAt(rs.getString("idPengajar"), i, 0);
                        list.getTableListPengajar().setValueAt(rs.getString("nama"), i, 1);                    
                    }
                    i=i+1;
                }
                rs.close();
            } catch(Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
    
    
    
    public void setPengajarListWindow(Matkul m, withMentor c) {
        list.getIdMatkul().setText(m.getIdMatkul());
        list.getNamaMatkul().setText(m.getNamaMatkul());
        list.getTanggalListPengajar().setText(c.getTanggal());
        kelas = c;
        matkul = m;
        showTableListPengajar();
        
        
    }
    
    
    
    
    
}
