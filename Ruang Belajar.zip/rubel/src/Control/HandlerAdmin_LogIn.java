/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
    import Model.*;
    import View.viewAdmin_LogIn;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
/**
 *
 * @author Hilmi
 */
public class HandlerAdmin_LogIn implements ActionListener{
    private viewAdmin_LogIn adminLogin;
    
    public HandlerAdmin_LogIn(){
        
        adminLogin = new viewAdmin_LogIn();
        adminLogin.setVisible(true);
        adminLogin.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(adminLogin.getLogInAdmin())){
            String password = adminLogin.getPasswordAdmin1().getText();
            String username = adminLogin.getUsernameAdmin1().getText();
            if ("admin".equals(username) && "admin".equals(password)) {
                HandlerAdmin f = new HandlerAdmin();
                f.setAdminWindow(username);
                adminLogin.dispose();
            } else{
                javax.swing.JOptionPane.showMessageDialog(null, "Username atau Password Salah");
            }
        } else if (source.equals(adminLogin.getGotoUserpage1())){
            HandlerUser_LogIn f = new HandlerUser_LogIn();
            adminLogin.dispose();
        }
    }
    
    public static void main(String[] args) {
        new HandlerAdmin_LogIn();
    }
    
    
    
}
